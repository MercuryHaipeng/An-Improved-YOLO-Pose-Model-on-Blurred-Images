### CrowdPose dataset

#### Documentation: 
https://github.com/jeffffffli/CrowdPose?tab=readme-ov-file

  

### Download script/URL:

[Train + Validation + Test Images](https://drive.google.com/file/d/1VprytECcLtU4tKP32SYi_7oDRbw7yUTL/view?usp=sharing) (Google Drive)

[Annotations](https://drive.google.com/drive/folders/1Ch1Cobe-6byB7sLhy8XRzOGCGTW2ssFv?usp=sharing) (Google Drive)