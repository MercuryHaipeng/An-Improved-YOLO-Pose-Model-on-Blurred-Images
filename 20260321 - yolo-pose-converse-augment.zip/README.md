# YOLO-Pose Converse-Augment Model

This folder includes the whole code files and the dataset description for the paper "An Improved YOLO-Pose Model for Pose Estimation on Blurred Images Generated to Protect Personal Privacy".

## Dataset Information
### CrowdPose Dataset Documentation
- The link in GitHub is: https://github.com/jeffffffli/CrowdPose?tab=readme-ov-file
- The reference is:

```biblatex
@article{li2018crowdpose,
  title={CrowdPose: Efficient Crowded Scenes Pose Estimation and A New Benchmark},
  author={Li, Jiefeng and Wang, Can and Zhu, Hao and Mao, Yihuan and Fang, Hao-Shu and Lu, Cewu},
  journal={arXiv preprint arXiv:1812.00324},
  year={2018}
}
```

### Configuration File
- Original `yaml` file: `CrowdPose.yaml`
- Blurred test set `yaml` file: `CrowdPose-Blurred.yaml`
- Download link(Google Drive): [Including images and annotations](https://drive.google.com/file/d/1KQYfmapG0KqbYR5u0HKDKKy_CzD9hyMr/view?usp=sharing)
  - Backup link: [Kaggle](https://www.kaggle.com/datasets/elmahy/crowdpose)

Upon downloading the dataset, users must update the data path specified in the configuration file (in YAML format) to reflect its actual storage location and subsequently partition the dataset into training, validation, and test subsets.


## Code Information
 - `Blurring_images.py`: This file is used to generate the blurred test images from the CrowdPose dataset, including Gaussian Blur, Motion Blur, and Defocus Blur.
 - `Train.py`: The file is used to train our proposed model, which includes training hyperparameter configuration.
 - `Test.py`: The file is used to test on blurred images directly while printing the evaluation metrics.
 - `yolon-pose-base.pt`: The pre-trained weight file of the baseline model, which is trained by `yolo12-pose.yaml`.
 - `yolo-pose-converse-augmentV4.pt`: The pre-trained weight file for the baseline model was generated using the configuration specified in `yolo12-pose.yaml`.
 - `ultralytics`: The source code corresponds to Ultralytics version 8.3.239.


 ## Requirements
 - The environment mentioned in the paper is as follows:
    - opencv-contrib-python==4.12.0.88
    - opencv-python==4.12.0.88 
    - torch==2.8.0+cu128
    - torchvision==0.23.0+cu129
- The `ultralytics` package need not be installed separately, as the included `ultralytics` directory contains the source code distribution corresponding to version 8.3.239.


## Usage Instructions
1. Download the CrowdPose dataset and extract its contents to the designated directory.
2. The training and validation sets are used to train the model according to the proposed methodology. The training script can be executed directly; however, the paths specified in `Train.py` and `CrowdPose.yaml` must be updated to reflect the local environment.
3. Execute `Blurring_images.py` to generate the blurred test images. Only the test-set images are modified; the corresponding annotation files remain unchanged.
4. Execute `Test.py` and print the evaluation metrics. Only the blurred test-set is used to evaluate. The path specified in `CrowdPose-Blurred.yaml`must be updated to reflect the local environment, and the test labels remain unchanged.