import torch
import torch.nn as nn
import torch.nn.functional as F
import copy


class Converse2D(nn.Module):    # 论文第3节-逆向卷积算子
    def __init__(self, in_channels, out_channels=None, kernel_size=5, scale=2, padding=2, padding_mode='circular', eps=1e-5):
        super(Converse2D, self).__init__()
        # 初始化参数
        self.in_channels = in_channels
        # 默认输出通道数等于输入通道数
        self.out_channels = out_channels if out_channels is not None else in_channels   
        self.kernel_size = kernel_size  # 卷积核大小
        self.scale = scale              # 上采样倍数, 论文中的stride
        self.padding = padding          # 填充大小
        self.padding_mode = padding_mode  # 填充模式
        self.eps = eps                  # 数值稳定性参数

        assert self.out_channels == self.in_channels, "Converse2D requires in_channels == out_channels for depthwise operation."

        # 可学习的卷积核权重kernel K (1, channels, kernel_h, kernel_w)
        self.weight = nn.Parameter(torch.randn(1, self.in_channels, self.kernel_size, self.kernel_size))
        # 可学习的偏置参数 - 正则化参数 λ
        self.bias = nn.Parameter(torch.zeros(1, self.in_channels, 1, 1))
        # 移除前向计算中的中间变量存储，避免深拷贝问题
        self.register_buffer(name='dumm_buffer', tensor=torch.zeros(1))
        # Softmax初始化 - 论文第4节
        self.weight.data = nn.functional.softmax(self.weight.data.view(1, self.in_channels, -1), dim=-1
            ).view(1, self.in_channels, self.kernel_size, self.kernel_size)
        self.force_float32 = True  # 是否强制使用float32计算

    def forward(self, x):
        # 强制使用float32计算以提高数值稳定性, 对应论文(6)和(7)式
        # original_dtype = x.dtype    # 保存原始数据类型
        # 如果启用强制 float32 或者输入是 half 精度，则转换为 float32
        if self.force_float32 or x.dtype == torch.float16:
            x = x.float()
        # 1. 边界填充
        if self.padding > 0:
            x = F.pad(x, pad=[self.padding]*4, mode=self.padding_mode, value=0)
        # 2. 计算自适应正则化参数
        self.biaseps = torch.sigmoid(self.bias - 9.0) + self.eps  # 避免除零错误
        _, _, h, w = x.shape  # 获取填充后的特征图尺寸, 也可写成 x.size()
        # 3. 上采样输入特征图 - 对应论文中的 F_{Y↑_s} (Y上采样s倍)
        STy = self.upsample(x)  # (B, C, H*s, W*s)
        if self.scale > 1:
            x_0 = F.interpolate(x, scale_factor=self.scale, mode='nearest')  # (B, C, H*s, W*s)
            # x_0 = torch.zeros(x.size(0), x.size(1), x.size(2)*self.scale, x.size(3)*self.scale,
                            #   device=x.device, dtype=x.dtype)  # 创建与x相同形状的零张量
        else:
            x_0 = x
        # 4. 计算卷积核的傅里叶变换 - 对应论文中的 F_K
        weight_float = self.weight.float()
        FK = self.p2o(weight_float, (h * self.scale, w * self.scale))  # (1, C, H*s, W*s)
        FKC = torch.conj(FK)  # 计算共轭复数 (1, C, H*s, W*s)
        FK2 = torch.pow(torch.abs(FK), 2)  # 计算幅值平方 |F_K|^2
        # 5. 在频域构建正则化最小二乘问题并求解 - 对应论文中的 (6) 式
        FKFy = FKC * torch.fft.fftn(STy, dim=(-2, -1))  # F_K^H * F_{Y↑_s}
        FL = FKFy + torch.fft.fftn(self.biaseps * x_0, dim=(-2, -1))  # F_K^H * F_{Y↑_s} + λ*F_{X↑_s}
        # 计算 FK * FL的分块下采样 - 对应论文中的 (FK*L) ⇓s
        x1 = FK.mul(FL)
        FKL = torch.mean(self.splits(x1, self.scale), dim=-1, keepdim=False)
        # 计算 F_K^2 的分块下采样 - 对应论文中的 |F_K|^2 ⇓s
        invW = torch.mean(self.splits(FK2, self.scale), dim=-1, keepdim=False)
        # (FK*L) ⇓s除以 (|F_K|^2 ⇓s + λ)
        invWKL = FKL.div(invW + self.biaseps)
        # 对应论文中的 F_K ⊙_s ((FK*L) ⇓s / (|F_K|^2 ⇓s + λ))
        FKCinvWKL = FKC*invWKL.repeat(1, 1, self.scale, self.scale) # invWKL最后两个维度重复scale变成(B, C, H*s, W*s)
        # 最终的求解结果
        FX = (FL - FKCinvWKL) / self.biaseps
        # 傅里叶逆变换得到空间域结果
        out = torch.real(torch.fft.ifftn(FX, dim=(-2, -1)))
        # 移除填充部分，只保留中间的有效区域
        if self.padding > 0:
            out = out[..., self.padding*self.scale:-self.padding*self.scale, self.padding*self.scale:-self.padding*self.scale]
        return out

    def upsample(self, x):
        '''s-fold upsampler
        Upsampling the spatial size by filling the new entries with zeros
        x: tensor image, N * C * W * H
        Y 插值比填充零效果更好
        '''
        B, C, H, W = x.shape
        s = self.scale
        # 直接在目标大小创建零张量
        out = torch.zeros(B, C, H * s, W * s, device=x.device, dtype=x.dtype)
        # 按 stride 填入原像素
        out[:, :, ::s, ::s] = x
        return out

    def p2o(self, psf, shape):
        '''
        Convert point-spread function to optical transfer function.
        otf = p2o(psf) computes the Fast Fourier Transform (FFT) of the
        point-spread function (PSF) array and creates the optical transfer
        function (OTF) array that is not influenced by the PSF off-centering.
        Args:
            psf: N, C, h, w
            shape: [H, W]
        Returns:
            otf: N, C, Hxs, Wxs
        '''
        # + 是 Python tuple 的连接操作
        otf = torch.zeros(psf.shape[:-2] + shape).type_as(psf)
        otf[..., :psf.shape[-2], :psf.shape[-1]].copy_(psf)
        otf = torch.roll(otf, (-int(psf.shape[-2]/2), -int(psf.shape[-1]/2)), dims=(-2, -1))
        otf = torch.fft.fftn(otf, dim=(-2, -1))
        return otf

    def splits(self, a, scale):
        '''
        Split tensor `a` into `scale x scale` distinct blocks.
        Args:
            a: Tensor of shape (..., W, H)
            scale: Split factor
        Returns:
            b: Tensor of shape (..., W/scale, H/scale, scale^2)
        '''
        *leading_dims, W, H = a.size()
        W_s, H_s = W // scale, H // scale
        # Reshape to separate the scale factors
        b = a.view(*leading_dims, scale, W_s, scale, H_s)
        # Generate the permutation order - len(leading_dims) = 2
        # 原来的维度[0,1,2,3,4,5] = [N,C,s1,W_s,s2,H_s] -> 变为 [N,C,W_s,H_s,s1,s2]
        permute_order = list(range(len(leading_dims))) + [len(leading_dims) + 1, len(leading_dims) + 3, len(leading_dims), len(leading_dims) + 2]
        b = b.permute(*permute_order).contiguous()
        # Combine the scale dimensions
        b = b.view(*leading_dims, W_s, H_s, scale * scale)
        return b

    def __deepcopy__(self, memo):
        # 自定义深拷贝方法，避免拷贝中间变量
        cls = self.__class__
        result = cls.__new__(cls)
        memo[id(self)] = result
        for k, v in self.__dict__.items():
            if k in ['weight', 'bias', 'dumm_buffer']:
                # 对于参数和buffer，使用标准的深拷贝
                setattr(result, k, copy.deepcopy(v, memo))
            else:
                # 对于其他属性，直接赋值引用
                setattr(result, k, v)
        return result


class ConverseUpsample(nn.Module):
    # 对应论文的第5节
    def __init__(self, *args):
        super().__init__()
        # 解析参数
        if len(args) == 1:
            self.in_channels = None
            self.scale = args[0]
        elif len(args) >= 2:
            self.in_channels = args[0]
            self.scale = args[1]
        else:   # 默认参数
            self.in_channels = None
            self.scale = 2
        # 如果提供了输入通道，则初始化Converse2D模块
        if self.in_channels is not None:
            self.converse = Converse2D(self.in_channels, self.in_channels, scale=self.scale)
        else:
            self.converse = None

    def forward(self, x):
        # 如果converse模块未初始化，则动态创建
        if self.converse is None:
            self.in_channels = x.shape[1]
            self.converse = Converse2D(self.in_channels, self.in_channels, scale=self.scale).to(x.device)
        # 使用Converse2D进行上采样
        out = self.converse(x)
        return out


class ConverseBlock(nn.Module):
    # 对应论文的第3.4节
    def __init__(self, in_channels, out_channels=None, kernel_size=5, scale=1, padding=2,
                 padding_mode='circular', eps=1e-5):
        super(ConverseBlock, self).__init__()
        out_channels = out_channels if out_channels is not None else in_channels
        # 初始化创建所有子模块：LayerNorm, 1x1 Conv, GELU, Converse2D
        self.conv1 = nn.Sequential(
            nn.LayerNorm(in_channels),
            nn.Conv2d(in_channels, 2 * out_channels, kernel_size=1, stride=1, padding=0),
            nn.GELU(),
            Converse2D(2*out_channels, 2*out_channels, kernel_size, scale, padding, padding_mode, eps),
            nn.GELU(),
            nn.Conv2d(2 * out_channels, out_channels, kernel_size=1, stride=1, padding=0)
        )
        self.conv2 = nn.Sequential(
            nn.LayerNorm(out_channels),
            nn.Conv2d(out_channels, 2 * out_channels, kernel_size=1, stride=1, padding=0),
            nn.GELU(),
            nn.Conv2d(2 * out_channels, out_channels, kernel_size=1, stride=1, padding=0)
        )

    def forward(self, x):
        # 残差连接结构
        x = x + self.conv1(x)   # 第一个卷积块 + 残差
        out = x + self.conv2(x)  # 第二个卷积块 + 残差
        return out
