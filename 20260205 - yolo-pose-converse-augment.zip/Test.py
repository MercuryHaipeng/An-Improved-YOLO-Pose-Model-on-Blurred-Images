'''
Test the blurred images on the Crowd-Pose blurred dataset
'''
import torch    
from ultralytics import YOLO
from pathlib import Path

# Fix the issue of loading Linux ckpt when the weight file is tesed on Windows.
import pathlib
pathlib.PosixPath = pathlib.WindowsPath

from ultralytics.utils.plotting import Annotator # Import Annotator to set dataset type
Annotator.number_dataset = 2 # 0(default):coco2017, 1:MPII, 2:CrowdPose


# The path settings below should be modified according to your own file structure.
DATASET_PATH = Path("./Datasets/CrowdPose-Blurred.yaml")
SAVE_PATH = Path("./Work/runs")
YOLO12_Converse_AugmentsV4_PATH = Path("./yolo-pose-converse-augment/weights/best.pt")


model = YOLO(YOLO12_Converse_AugmentsV4_PATH)
val_params = {
    'data': DATASET_PATH,
    'split': "test", # Use test set for evaluation, not val set
    'project': SAVE_PATH,
    'device': 0, # Use GPU device 0, or set to 'cpu' to swithc to CPU
}
results = model.val(**val_params)

# Print evaluation meterics
print('results.box.map50', f"{results.box.map50:.5f}")
print('results.box.map75', f"{results.box.map75:.5f}")
print('results.box.map50-95', f"{results.box.map:.5f}")
print('results.box.mp', f"{results.box.mp:.5f}") 
print('results.box.mr', f"{results.box.mr:.5f}")
print('results.box.f1', results.box.f1)

print('results.pose.map50', f"{results.pose.map50:.5f}")
print('results.pose.map75', f"{results.pose.map75:.5f}")
print('results.pose.map50-95', f"{results.pose.map:.5f}")
print('results.pose.mp', f"{results.pose.mp:.5f}") 
print('results.pose.mr', f"{results.pose.mr:.5f}")
print('results.pose.f1', results.pose.f1)

print('result.speed', results.speed)