'''
Training code for the proposed YOLO-Pose model
'''
import torch # import torch to use gpu device
from ultralytics import YOLO
from pathlib import Path

import albumentations as A # import albumentations for advanced data augmentations

from ultralytics.utils.plotting import Annotator
# number_dataset ---- 0:coco2017, 1:MPII, 2:CrowdPose
Annotator.number_dataset = 2 # Choose the CrowdPose blurred dataset to train


# The path settings below should be modified according to your own file structure.
# Load the yaml file
model = YOLO("/home/aistudio/ultralytics-8.3.239-20251223/ultralytics/cfg/models/12/yolo12-pose-converse.yaml")
# Load the pretrained model weights to accelerate training
model.load("/home/aistudio/202507151240.pt")
DATA_TRAIN_PATH = Path("/home/aistudio/training_data_yaml/crowd-pose.yaml")
SAVE_PATH = Path("/home/aistudio/work") # Path to save the trained model and logs


advanced_transforms = [
# 1. Simulate Motion Blur. Note: It must be an odd number.
A.MotionBlur(blur_limit=(7, 21), p=0.4),
# 2. Simulate Gaussian  Blur.
A.GaussianBlur(blur_limit=(7, 21), p=0.4),
# 3. Enhance Contrast (Mandatory for extremely large blurs)
A.RandomBrightnessContrast(brightness_limit=0.3, contrast_limit=0.3, p=0.5),
# 4. Downsampling Enhancement. It works better in combination with the Downscale effect.
A.Downscale(scale_range=(0.3, 0.7), p=0.3),
]

train_params = {
    "data": DATA_TRAIN_PATH,
    "epochs": 100,
    "imgsz": 640,
    "batch": 64,
    "device": 0, 
    "project": SAVE_PATH,
    "name": "yolo-pose-converse-augment",
    "exist_ok": True,
    "patience": 20,
    "optimizer": "AdamW",
    "lr0": 0.001,
    "lrf": 0.01, 
    "cos_lr": True,
    "amp": False,   # When use deconvolution layers, amp must be set False
    "augmentations": advanced_transforms, # Use custom data augmentations
    "save_period": 45,   
}

model.train(**train_params) # Begin training