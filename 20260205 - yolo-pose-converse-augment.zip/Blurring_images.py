# ================================================================== #
# This file is used to blur the images in CrowPose test set
# ================================================================== #
import cv2
import os
import glob
from pathlib import Path
import numpy as np
from ultralytics import YOLO


def draw_keypoints_on_blurred_images(image_dir, labels_dir, output_dir, kernel_size=(21, 21), visibility_threshold=1):
    """
    Load the labels file and blur the images, then draw keypoints on the blurred images.
    Args:
        image_dir: The original image folder
        labels_dir: The labels folder
        output_dir: The output folder of blurred images 
        kernel_size: The size of the blurring kernel must be a positive odd number.
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Verify whether the size of the kernel is an odd number.
    if kernel_size[0] % 2 == 0 or kernel_size[1] % 2 == 0:
        print(f"Warning: The kernal size {kernel_size} include even, and woulde be changed to odd automatively.")
        kernel_size = (kernel_size[0] + 1 if kernel_size[0] % 2 == 0 else kernel_size[0],
                       kernel_size[1] + 1 if kernel_size[1] % 2 == 0 else kernel_size[1])
        print(f"The kernal size is: {kernel_size}")

    # Get all image files
    image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp']
    image_files = []
    for ext in image_extensions:
        image_files.extend(glob.glob(os.path.join(image_dir, ext)))
    
    processed_count = 0
    for image_path in image_files:
        image = cv2.imread(image_path)
        if image is None:
            print(f"The path cannot be read.: {image_path}")
            continue
            
        # Get all the labels
        image_name = os.path.splitext(os.path.basename(image_path))[0]
        label_path = os.path.join(labels_dir, f"{image_name}.txt")

        if not os.path.exists(label_path):
            print(f"The label file isn't found: {label_path}")
            continue
            
        # Read Labels
        with open(label_path, 'r') as f:
            lines = f.readlines()
        
        # Blur all human
        blurred_image = image.copy()
        for person_idx, line in enumerate(lines):
            parts = line.strip().split()
            if len(parts) < 5:
                continue
            # Normalized coordinates
            class_id = int(parts[0])
            x_center = float(parts[1])
            y_center = float(parts[2])
            width = float(parts[3])
            height = float(parts[4])
            # Only process the human class (usually 0).
            if class_id == 0:
                # Convert normalized coordinates to pixel coordinates
                h, w = image.shape[:2]
                x1 = int((x_center - width / 2) * w)
                y1 = int((y_center - height / 2) * h)
                x2 = int((x_center + width / 2) * w)
                y2 = int((y_center + height / 2) * h)
                # Make sure the coordinates are within the image range
                x1 = max(0, x1)
                y1 = max(0, y1)
                x2 = min(w, x2)
                y2 = min(h, y2)

                # Check if the bounding box is valid
                if x2 <= x1 or y2 <= y1:
                    print(f"Skip invalid bounding boxes: ({x1}, {y1}, {x2}, {y2})")
                    continue
                # Extract the ROI area and apply blurring.
                roi = image[y1:y2, x1:x2]   
                if roi.size > 0:
                    try:
                        blurred_roi = cv2.GaussianBlur(roi, kernel_size, 0)
                        # Put the blurred area back into the original image
                        blurred_image[y1:y2, x1:x2] = blurred_roi
                    except Exception as e:
                        print(f"An error occurred while processing the bounding box: {e}")
                        continue
                
        image_with_keypoints = blurred_image.copy()        
        
        # Save the results
        output_path = os.path.join(output_dir, os.path.basename(image_path))
        cv2.imwrite(output_path, image_with_keypoints)
        processed_count += 1
        if processed_count % 100 == 0:
            print(f"Processing: {processed_count} images")
    
    print(f"Processing completed! A total of {processed_count} images were processed.")

# The main function
if __name__ == "__main__":
    image_directory = "./CrowdPose/images/test"  # Replace with the path of your image folder
    labels_directory = "./CrowdPose/labels/test"  # Replace with the path of your labels folder  
    output_directory = "./CrowdPose_Blurred/images/test"  # Replace with the path of blurred image folder

    # blurring process
    draw_keypoints_on_blurred_images(
        image_dir=image_directory,
        labels_dir=labels_directory,
        output_dir=output_directory,
        kernel_size=(21, 21)    # Set up the differetn kernel size
    )